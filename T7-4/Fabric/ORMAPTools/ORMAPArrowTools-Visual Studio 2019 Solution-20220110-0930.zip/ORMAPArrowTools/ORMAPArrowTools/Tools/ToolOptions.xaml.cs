﻿using System.Windows.Controls;

namespace ORMAPArrowTools.Tools
{
    /// <summary>
    /// Interaction logic for ToolOptionsView.xaml.
    /// </summary>
    public partial class ToolOptionsView : UserControl
    {
        public ToolOptionsView()
        {
            InitializeComponent();
        }
    }
}
